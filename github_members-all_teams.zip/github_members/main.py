import argparse
import github_service
import csv_export as csv


def get_args(parser):

    args = vars(parser.parse_args())
    token = args["token"]
    organisation = args["org"]

    return token, organisation


def create_parser():

    parser = argparse.ArgumentParser(
        description="Github team members parser")
    parser.add_argument(
        "--token",
        help="Github token",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--org",
        help="Github organisation name",
        type=str,
        required=True,
    )
    return parser


def main():
    parser = create_parser()
    github_token, org_name = get_args(parser)

    github_organisation = github_service.get_organisation(
        github_token, org_name)

    github_teams = github_service.get_teams(github_organisation)

    exporter = csv.CsvExporter()
    exporter.init()
    for team in github_teams:
        members = github_service.get_members(team)
        exporter.export_users(team, members)


if __name__ == "__main__":
    main()
