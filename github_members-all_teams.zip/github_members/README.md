# How to run

pip install PyGithub
python3 ./main.py --token "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" --org "KAR-AUTO"
