from github import Github
import github.Team
import github.Organization


def get_organisation(token: str, org_name: str):
    g = Github(token)
    return g.get_organization(org_name)


def get_teams(org: github.Organization.Organization):
    return org.get_teams()


def get_members(team: github.Team.Team):
    return team.get_members()
