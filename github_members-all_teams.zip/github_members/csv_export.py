from typing import List
import github.NamedUser
import github.Team
import csv
from datetime import datetime


class CsvExporter:
    def __init__(self):
        current_date_time = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.file_name = f'exported_{current_date_time}.csv'

    def init(self):
        header = ['team', 'login', 'email', 'bio']

        with open(self.file_name, 'w', encoding='UTF8') as f:
            # create the csv writer
            writer = csv.writer(f)

            # write the header
            writer.writerow(header)

    def export_users(self, github_team: github.Team.Team, github_users: list[github.NamedUser.NamedUser]):
        with open(self.file_name, 'a', encoding='UTF8') as f:
            writer = csv.writer(f)

            for user in github_users:
                row_data = [github_team.name, user.login, user.email, user.bio]
                writer.writerow(row_data)
